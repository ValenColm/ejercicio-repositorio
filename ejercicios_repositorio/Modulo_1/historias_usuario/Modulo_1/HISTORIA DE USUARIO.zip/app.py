from archivos import guardar_csv, cargar_csv
from servicios import menu, agregar_producto,eliminar_producto,buscar_producto,actualizar_producto,calcular_estadisticas,inventory
menu()